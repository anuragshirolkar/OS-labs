#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <stdio.h>
#include <iomanip>
#include <string>

#include "primaryThread.cpp"
using namespace std;

int main()
{
	primary_thread pt;
	pt.start();
    return 0;
}
