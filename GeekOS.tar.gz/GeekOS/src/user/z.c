#include <conio.h>

int main(int argc, char **argv) 
{
    Print("Hello World !!!\n");
    return 1;
}
